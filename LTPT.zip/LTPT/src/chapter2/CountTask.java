package chapter2;

public class CountTask   {
	private int count=0;


	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	public void inc() {
		++count;
	}

}
