package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import entity.Brand;
import entity.Categories;
import factory.MySessionFactory;

public class CategoryDao {
private SessionFactory sessionFactory;
	
	public CategoryDao() {
		sessionFactory = MySessionFactory.getInstance().getSessionFactory();
	}
	
	public boolean add(Categories categories) {
		
		Transaction tr = null;;
		try(
				Session session = sessionFactory.openSession();
				){
			tr  = session.beginTransaction();			
			session.persist(categories);
			tr.commit();
			
			return true;
		}catch (Exception e) {
			e.printStackTrace();
			tr.rollback();
		}
		
		return false;
		
	}
public Categories getCat(int id) {
		
		Transaction tr = null;;
		try(
				Session session = sessionFactory.openSession();
				){
			tr  = session.beginTransaction();
			Categories cate  = session.find(Categories.class, id);
			tr.commit();
			
			return cate;
		}catch (Exception e) {
			e.printStackTrace();
			tr.rollback();
		}
		
		return null;
		
	}
public List<Categories> getAll() {
	
	Transaction tr = null;;
	try(
			Session session = sessionFactory.openSession();
			){
		tr  = session.beginTransaction();
		String sql = "select * from Categories";
		List<Categories> list = session.createNativeQuery(sql, Categories.class).getResultList();
		tr.commit();
		
		return list;
	}catch (Exception e) {
		e.printStackTrace();
		tr.rollback();
	}
	
	return null;
	
}

	

}
