package entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Categories")
public class Categories {

	@Id
	@Column(name = "category_id")
	private int categorId;
	private String categoryName;
	//@Column(name = "category_name")
	public Categories(int categorId, String categoryName) {
		super();
		this.categorId = categorId;
		this.categoryName = categoryName;
	}
	public Categories() {
		super();
	}
	public Categories(String categoryName) {
		super();
		this.categoryName = categoryName;
	}
	public int getCategorId() {
		return categorId;
	}
	public void setCategorId(int categorId) {
		this.categorId = categorId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	@Override
	public String toString() {
		return "Categories [categorId=" + categorId + ", categoryName=" + categoryName + "]";
	}
	
	
	
}
