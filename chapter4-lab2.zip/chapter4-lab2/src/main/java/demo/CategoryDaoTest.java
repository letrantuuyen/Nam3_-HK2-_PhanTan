package demo;

import dao.CategoryDao;
import entity.Categories;

public class CategoryDaoTest {
	
	public static void main(String[] args) {
		CategoryDao categoryDao = new CategoryDao();
		categoryDao.add(new Categories(10, "Tu Uyen"));
		categoryDao.add(new Categories(11, "Tu Uyen"));
		categoryDao.add(new Categories(12, "Tu Uyen"));
	//	Categories c = categoryDao.getCat(10);
		
		categoryDao.getAll().forEach(b -> System.out.println(b));
	
	
	}
}
