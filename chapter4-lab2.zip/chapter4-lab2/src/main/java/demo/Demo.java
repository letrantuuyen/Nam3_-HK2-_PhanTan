package demo;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;

public class Demo {
	public static void main(String[] args) {
		
		
	}
}
