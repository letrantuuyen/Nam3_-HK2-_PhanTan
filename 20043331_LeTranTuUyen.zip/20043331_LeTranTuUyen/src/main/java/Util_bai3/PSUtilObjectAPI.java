package Util_bai3;

import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.JsonValue;

import entity_bai3.PS;

public class PSUtilObjectAPI {
	
	private  static final  String PATH = "data/ps.json"; 
	
	public static PS ObjectAPI() {
		JsonReader read = null;
		PS psss = new PS();
		try {
			read = Json.createReader(new FileReader(PATH));
			JsonObject oj = read.readObject();
			psss = new PS();
			psss.setStateName(oj.getString("StateName"));
			psss.setAbbreviation(oj.getString("Abbreviation"));
			psss.setCapital(oj.getString("Capital"));
			psss.setStateHood(oj.getInt("Statehood"));
			psss.setId(oj.getInt("ID"));
			JsonArray js = read.readArray();
			for (JsonValue jsonValue : js) {
				if(js instanceof JsonObject) {
					JsonObject ob = js.asJsonObject();
					System.out.println(ob);
					JsonValue value = read.readValue();
					psss.getAbbreviation();
					psss.getStateName();
					psss.getCapital();
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			read.close();
		}
		
		return psss;
	}

}
