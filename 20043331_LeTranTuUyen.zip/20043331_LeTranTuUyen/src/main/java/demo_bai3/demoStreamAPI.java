package demo_bai3;

import Util.PersonUtilStreamAPI;

public class demoStreamAPI {

	public static void main(String[] args) {
		System.out.println(PersonUtilStreamAPI.StreamAPI("data/person.json"));
	}
}
