package demo_bai3;

import Util_bai3.PSUtilObjectAPI;

public class demoObjectAPI {
	
	public static void main(String[] args) {
		System.out.println(PSUtilObjectAPI.ObjectAPI());
	}
}
