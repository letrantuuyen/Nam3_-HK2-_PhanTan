package demo_bai3;

import Util_bai3.PSUtil_streamAPI;

public class demo3 {

	public static void main(String[] args) {
		System.out.println(PSUtil_streamAPI.read("data/ps.json"));
	}
}
 